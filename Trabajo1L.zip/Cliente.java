import java.util.Scanner;
class Cliente {
    
    private String nombre;
    private String correo;
    private String telefono;
    private String direccion;
    private String codigoCliente;

    public Cliente(String nombre, String correo, String telefono, String direccion, String codigoCliente) {
        this.nombre = nombre;
        this.correo = correo;
        this.telefono = telefono;
        this.direccion = direccion;
        this.codigoCliente = codigoCliente;
    }
  
  public Cliente(String nombre, String correo, String telefono, String direccion) {
        this.nombre = nombre;
        this.correo = correo;
        this.telefono = telefono;
        this.direccion = direccion;
        this.codigoCliente = "Sin asignar";
    }
   public void setCodigo(String codigoCliente){
     this.codigoCliente = codigoCliente;
   }

    public void consultarProductos () {
        System.out.println("Desodorante = 20.000");
        System.out.println("Cepillo de dientes= 8.000");
        System.out.println("Shampoo= 30.000");
    }

    public void mostrarContenido(){
    System.out.println("Nombre: " + this.nombre);
    System.out.println("Correo: " + this.correo); 
    System.out.println("Télefono: "+ this.telefono);
    System.out.println("Dirección: "+ this.direccion);
    System.out.println("Codigo: "+ this.codigoCliente);
    System.out.println("Como cliente puede:");
    System.out.println("1.Consultar productos");
    System.out.println("2. Salir");
      Scanner scanner = new Scanner(System.in);
      int opcion = scanner.nextInt();
        switch(opcion){
          case 1:
            consultarProductos();
            break;
          case 2:
            break;
        }   
    }
}