import java.util.Scanner;
class Main{

    public static void main(String[] args) {
      
      Cliente cliente1 = new Cliente("Miguel", "Miguel213@hotmail.com", "3043423467", "Cll 36 sur 25-543");
      
      Cajero cajero1 = new Cajero("Carlos", "carlos523@xyz.com", 1037);
      
      Administrador administrador1 = new Administrador("Luis", "luis123@xyz.com", 1090);
      Scanner scanner = new Scanner(System.in);
      int opcion;
      do {

        System.out.println("Menú");
        System.out.println("Opción 1: Para acceder a una cuenta de cajero");
        System.out.println("Opción 2: Para acceder a una cuenta de administrador");
        System.out.println("Opción 3: Para acceder a una cuenta de cliente");
        System.out.println("Opción 4: Para salir");
    
       opcion = scanner.nextInt();
      
      switch(opcion){
        case 1:
        cajero1.mostrarContenido();
          break;
        case 2:
        administrador1.mostrarContenido(cajero1,cliente1);
          break;
        case 3:
        cliente1.mostrarContenido();
          break;
        case 4:
          break;
      }       
      } while(opcion != 4); 
    }
}