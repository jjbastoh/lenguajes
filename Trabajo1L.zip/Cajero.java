import java.util.Scanner;
class Cajero {
    
    private String nombre;
    private String correo;
    private int claveCajero;
    private String codigo;

    public Cajero(String nombre, String correo, int claveCajero, String codigo) {
        this.nombre = nombre;
        this.correo = correo;
        this.claveCajero = claveCajero;
        this.codigo = codigo;  
    }
  public Cajero(String nombre, String correo, int claveCajero) {
        this.nombre = nombre;
        this.correo = correo;
        this.claveCajero = claveCajero;
        this.codigo = "Sin asignar";  
    }
    public void setCodigo(String codigo){
      this.codigo = codigo;
    }
  public void registroVenta(){
    Scanner scanner = new Scanner(System.in);
    System.out.println("Ingrese el producto:");
    String producto = scanner.nextLine();
    System.out.println("Ingrese la cantidad:");
    int cantidad = scanner.nextInt();
    System.out.println("Venta registrada con exito!");
  }
    public void mostrarContenido() {
      System.out.println("Ingrese la clave del cajero: ");
      Scanner scanner = new Scanner(System.in);
      int claveCaj = scanner.nextInt();
      if (claveCaj == this.claveCajero){
            System.out.println("Nombre: " + this.nombre);
    System.out.println("Correo: " + this.correo);  
    System.out.println("Clave Cajero: " + this.claveCajero); 
    System.out.println("Código: "+ this.codigo);
    System.out.println("Al ser un cajero puede:");
    System.out.println("1.Registrar una venta");
    System.out.println("2.Salir");
        int opcion = scanner.nextInt();
        switch (opcion){
          case 1: 
         registroVenta();
            break;
          case 2:
            break;
        }
    }    
        else{
            System.out.println("Clave incorrecta vuelve a intentarlo");
        }
    }
}