import java.util.Scanner;
class Administrador {
    private String nombre;
    private String correo;
    private int claveAdministrador;
  

    public Administrador(String nombre, String correo, int claveAdministrador) {
        this.nombre = nombre;
        this.correo = correo;
        this.claveAdministrador = claveAdministrador;
    }

    public void asignarCodigoPerfil(Cajero cajero1) {
      Scanner scanner = new Scanner(System.in);
        System.out.println("¿Qué código deseas asignar?");
      String cod = scanner.nextLine();
      cajero1.setCodigo(cod);
      System.out.println("Código asignado con exito!");
    }
   public void asignarCodigoPerfil(Cliente cliente1) {
     Scanner scanner = new Scanner(System.in);
        System.out.println("¿Qué código deseas asignar?");
     String cod = scanner.nextLine();
      cliente1.setCodigo(cod);
     System.out.println("Código asignado con exito!");
    }
    public void mostrarContenido(Cajero cajero1, Cliente cliente1) {
       Scanner scanner = new Scanner(System.in);
        System.out.print("Ingrese la clave de administrador: ");
        int claveAdmin = scanner.nextInt();

        if (claveAdmin == this.claveAdministrador) {
            System.out.println("Nombre: " + this.nombre);
            System.out.println("Correo: " + this.correo);
            System.out.println("Clave de Administrador: " + this.claveAdministrador);

            System.out.println("Como administrador, puede realizar las siguientes acciones:");
            System.out.println("1. Asignar un código a un perfil");
            System.out.println("2. Salir");

            int opcion = scanner.nextInt();

            switch (opcion) {
                case 1:
                    System.out.println("¿A qué perfil desea asignarle un código?");
                    System.out.println("1: Cajero");
                    System.out.println("2: Cliente");
                    int opcion2 = scanner.nextInt();
                    switch (opcion2) {
                        case 1:
                            asignarCodigoPerfil(cajero1);
                            break;
                        case 2:
                            asignarCodigoPerfil(cliente1);
                            break;
                    }
                    break;                       
                case 2:
                    System.out.println("Saliendo...");
                    break;
                default:
                    System.out.println("Opción no válida");
            }
        } else {
            System.out.println("Clave incorrecta, vuelva a intentarlo.");
        }
    }
}